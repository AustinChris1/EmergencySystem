import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Flame, Heart, Shield, Info, ChevronLeft, ChevronRight, Moon, Sun } from 'lucide-react';
import { motion } from 'framer-motion';

const Sidebar = () => {
    const [isExpanded, setIsExpanded] = useState(false);
    const location = useLocation();
    const [darkMode, setDarkMode] = useState(false);

    useEffect(() => {
        if (darkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, [darkMode]);

    const toggleSidebar = () => {
        setIsExpanded(!isExpanded);
    };

    const toggleDarkMode = () => {
        setDarkMode(!darkMode);
    };

    const navItems = [
        { path: "/", label: "Fire", icon: <Flame /> },
        { path: "/health", label: "Medical", icon: <Heart /> },
        { path: "/security", label: "Security", icon: <Shield /> },
        { path: "/general", label: "General", icon: <Info /> },
    ];

    return (
        <div className="relative z-50">
            {/* Sidebar */}
            <motion.aside
                initial={{ width: "4rem" }}
                animate={{ width: isExpanded ? "16rem" : "4rem" }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className={`fixed top-0 left-0 h-screen bg-gray-800 text-white z-40 dark:bg-gray-900 dark:text-gray-100`}
                style={{ height: '100vh' }} // Ensure full height on mobile
            >
                {/* Logo or Title */}
                <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: isExpanded ? 1 : 0, x: isExpanded ? 0 : -20 }}
                    transition={{ duration: 0.2, delay: isExpanded ? 0.1 : 0, ease: "easeInOut" }}
                    className="p-4 border-b border-gray-700 overflow-hidden dark:border-gray-700"
                >
                    <h2 className="text-xl font-semibold whitespace-nowrap">Emergency Hub</h2>
                </motion.div>

                {/* Navigation Items */}
                <nav className="p-4">
                    <ul className="space-y-2">
                        {navItems.map((item) => (
                            <li key={item.path}>
                                <Link
                                    to={item.path}
                                    className={`flex items-center space-x-3 p-2 rounded-md hover:bg-gray-700 dark:hover:bg-gray-700 ${
                                        location.pathname === item.path ? 'bg-gray-700 dark:bg-gray-700' : ''
                                    }`}
                                >
                                    <span>{item.icon}</span>
                                    <motion.span
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: isExpanded ? 1 : 0, x: isExpanded ? 0 : -20 }}
                                        transition={{ duration: 0.2, delay: isExpanded ? 0.1 : 0, ease: "easeInOut" }}
                                        className="whitespace-nowrap overflow-hidden"
                                    >
                                        {item.label}
                                    </motion.span>
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>

                {/* Expansion Toggle Button (Always Visible) */}
                <button
                    onClick={toggleSidebar}
                    className="absolute top-4 right-0 transform translate-x-1/2 bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full dark:bg-gray-700 dark:hover:bg-gray-600"
                >
                    {isExpanded ? <ChevronLeft /> : <ChevronRight />}
                </button>

                {/* Dark Mode Toggle Button */}
                <button
                    onClick={toggleDarkMode}
                    className="absolute bottom-4 left-4 bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full dark:bg-gray-700 dark:hover:bg-gray-600"
                >
                    {darkMode ? <Sun /> : <Moon />}
                </button>
            </motion.aside>

            <div className={`pl-4 transition-all duration-300 ${isExpanded ? 'pl-64' : 'pl-16'} dark:bg-gray-800 dark:text-gray-200`}>
            </div>
        </div>
    );
};

export default Sidebar;